import logo from './logo.svg';
import './App.css';
import TodosContainer from './containers/TodosContainer';

function App() {
  return <TodosContainer></TodosContainer>;
}

export default App;
